/*
------------ Assignment Info ------------

--> Assignment 1 - WPR381
--> Topic: Spotify API
--> Members:

  -> Aidan Beckley - 577501
  -> Robert Cooke - 577671
  -> Thokozani Angel Mncube - 577938
  -> Calvin Jordaan - 577859

!!!!!!!!!! Important Note(s) !!!!!!!!!!

--> Please remember to install the node modules: npm install node

*/

// Requirements:
const readline = require('readline-sync'); // Used to get the input of the user.
const fetch = require('node-fetch'); // Used to fench the locations of certain urls.

const clientId = '499eed45d68a44808b3b7b8385a5493c';  // Is the client id of the API host.
const clientSecret = '542b458e8c9b4889b1b43bc483e4ab5e';  // Is the client secret of the API host.

// Boolean value used to see if the user wants to stop searching for songs.
let runSearch = true;

// The following function retrieves the access token.
async function getAccessToken() {
  // The try catch will catch any error(s) that might appear while retrieving an access token.
  try {
    // The following will assign the user an access token based on the client id and client secret.
    const response = await fetch('https://accounts.spotify.com/api/token', {
      // The information will be posted to the server, so it can assign the user an access token.
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64'),
      },
      body: 'grant_type=client_credentials',
    });

    // In the event of an error occuring, while assigning an access token to an user the following statement will run.
    if (!response.ok) {
      // This will avoid the execution of any code following the statement and go to the catch.
      throw new Error(`Failed to get access token: ${response.statusText}`);
    };

    // The following parses the response as JSON.
    const data = await response.json();
    // The access token is return so it can be used by the trackData() function.
    return data.access_token;
  }
  // The catch will display the error in the console.
  catch (error) {
    // Display error.
    console.error('Error:', error.message);
    throw error;
  };
};

// The following function is used to search for the song that the user entered.
async function search(query, accessToken) {

  // accessToken: Is the access token that was assigned to the user.
  // query: Is the name of the song the user is searching for.

  // If any errors occur while searching for the song, the try catch will catch it.
  try {
    // The following will retrieve the information about the song on Spotify and store it in searchResponse.
    const searchResponse = await fetch(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=5`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });

    // If any errors took place while searching for the information, the following statement will run.
    if (!searchResponse.ok) {
      // This will avoid the execution of any code following the statement and go to the catch.
      throw new Error(`Search request failed: ${searchResponse.statusText}`);
    };

    // Converts the response to JSON.
    const data = await searchResponse.json();

    // The information is return to be displayed in the terminal.
    return data.tracks.items.map(track => ({
      // Track ID
      id: track.id,
      // Track Name
      name: track.name,
      // Name of the artists
      artists: track.artists.map(artist => artist.name).join(', '),
      // Album
      album: track.album.name
    }));
  }
  // If any errors occur the following will be used to display it in the terminal.
  catch (error) {
    // Display error
    console.error('Error: ', error.message);
    throw error;
  };
};

// The following is used to display more information about the track to the user.
async function fetchTrackData(trackId, accessToken) {

  // trackId: Is the ID of the track that the user selected.
  // accessToken: Is the access token that was assigned to the user.

  // The following try catch handles the errors that might occur during the display of the selected track info.
  try {
    // The following retrieves the information about the selected track on Spotify.
    const trackResponse = await fetch(`https://api.spotify.com/v1/tracks/${trackId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });

    // In the event of an error occuring while retrieving the information about the selected track, the following statement will run.
    if (!trackResponse.ok) {
      throw new Error(`Track data request failed: ${trackResponse.statusText}`);
    }

    // The data that was retrieved is converted to JSON.
    const data = await trackResponse.json();

    // Displays all the information of the response.
    // console.log('Search API response:', data);

    // Returns the required information (Artist(s), song, preview link, and album).
    return {
      id: data.id,
      artists: data.artists.map(artist => artist.name).join(', '),
      song: data.name,
      preview_url: data.preview_url,
      album: data.album.name,
    };
  }
  // In the event of there being an error, the following will dipslay it.
  catch (error) {
    console.error('Error: ', error.message);
    throw error;
  };
};

// The following IIFE (Immediately Invoked Function Expression), will run immediately when index.js file runs.
(async () => {

  console.log('----------------------------------------------------------');
  console.log('Welcome to the Spotify API track searcher');
  console.log('----------------------------------------------------------');
  
  // The following while loop will continue to run until the user does not want to search anymore songs.
  while(runSearch == true)
  {
    // Variables used to get the user's input, in the track name section.
    let hasName = false;
    let trackName = '';

    while(hasName == false)
    {
      // The following prompts the user a question and stores their input in the trackName variable.
      trackName = readline.question('Enter the Spotify track name: ');
      console.log('----------------------------------------------------------');

      // In the event of the user not entering any values into the terminal the following statement will run.
      if (!trackName.trim()) {
        // Indication to user that they have to enter values in the terminal.
        console.error('(!) Note: Track name cannot be empty.');
        console.log('----------------------------------------------------------');
      }
      else
      {
        hasName = true;
      };
    };
    
    // In the event of any errors occuring while displaying the final output, the following try catch will catch it.
    try {
      // Assigning access token to the user and storing it in the accessToken variable.
      const accessToken = await getAccessToken();

      // Data of the identified tracks that had the same name that the user entered.
      const trackData = await search(trackName, accessToken);

      // In the event of there not being any tracks that the user search for the following statement will run.
      if (trackData.length === 0) {
        console.log("No Spotify track found");
        return;
      }

      // Variables used to get the user's input, in the track list section.
      let selectedOption = false;
      let reqTrack = '';

      while(selectedOption == false)
      {
        // The following will display a list of all the tracks with the name that the user entered.
        console.log('Searching song: ');
        trackData.forEach((track, index) => {
          console.log(`${index + 1}. ${track.name} by ${track.artists} (Album: ${track.album})`);
        });

        console.log('----------------------------------------------------------');

        // Prompts the user to enter a number of the track they want the information for.
        // It then stores their input into the reqTrack variable.
        reqTrack = readline.questionInt('Enter the number of the track you want to fetch details for: ') - 1;

        console.log('----------------------------------------------------------');

        // In the event of the user entering a value that was not listed, the following statement will run.
        if (reqTrack < 0 || reqTrack >= trackData.length) {
          console.error(`(!) Note: Option ${reqTrack + 1} does not exist. Please select one of the available options.`);
          console.log('----------------------------------------------------------');
        }
        else
        {
          // If the user entered one of the available options, it will display more details about the track to the user.
          selectedOption = true;
        };
      };
      
      // ID of the track that the user selected.
      const reqTrackID = trackData[reqTrack].id;

      // Data returned from the fetchTrackData(), is stored in the tData variable.
      const tData = await fetchTrackData(reqTrackID, accessToken);

      console.log('Track Details:')

      // The final output is displayed.
      console.log(`\nArtists: ${tData.artists}`);
      console.log(`Song: ${tData.song}`);
      console.log(`Preview URL: ${tData.preview_url}`);
      console.log(`Album: ${tData.album}`);

      console.log('----------------------------------------------------------');

    }
    // In the event of any error occuring the following will be displayed.
    catch (error) {
      console.error('Error fetching track data:', error.message);
      console.log('----------------------------------------------------------');
    };


    // The following gets the input from the user to determine if they want to search for another track.
    const searchAgain = readline.question('Would you like to search for another track? Enter Y -> Yes and N -> No\nYour option: ');
      
    // If the user enter Y or y, they will be able to search for another track.
    if(searchAgain == 'Y' || searchAgain == 'y')
    {
      // If the user searches for another track the terminal will clear the previous items.
      runSearch = true;
      console.clear();
    }
    else
    {
      // Confirmation of exit.
      console.log('----------------------------------------------------------');
      console.log('Thank you for using the Spotify API track searcher.');
      console.log('----------------------------------------------------------');
      runSearch = false;
    };
  };
  
})();
